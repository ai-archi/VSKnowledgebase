# 用户故事

**ID**: {{storyId}}  
**创建日期**: {{date}}  
**优先级**: {{priority}}

## 用户故事描述

作为 **{{userRole}}**，  
我希望 **{{userGoal}}**，  
以便 **{{businessValue}}**。

## 验收标准

- [ ] 标准1
- [ ] 标准2
- [ ] 标准3

## 详细描述

{{detailedDescription}}

## 相关需求

- [[需求-{{relatedRequirement}}]]

## 相关任务

- [ ] 任务1
- [ ] 任务2

## 备注

{{notes}}

